Here is a quick sample on what you can (and how you can do) several stuffs in easylogging++ (and Qt)

Please ignore any crashes (if you observe) as we have not build this sample to handle crashes

![Sample screenshot](sample.gif)
